#import <Flutter/Flutter.h>

@interface FlutterZipArchivePlugin : NSObject<FlutterPlugin>
@end
