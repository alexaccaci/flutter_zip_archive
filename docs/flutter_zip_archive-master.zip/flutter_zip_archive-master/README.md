# flutter_zip_archive
flutter zip 压缩 解压 密码

ios 使用 https://github.com/ZipArchive/ZipArchive
android 使用 zip4j http://www.lingala.net/zip4j/
